package com.fgustavo.proyecto_v1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Pacientes")
public class PacienteController {
    @RequestMapping("/")
    public String paciente(){
        return "pacientes/inicio";
    }
}
