package com.fgustavo.proyecto_v1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class InicioController {

    @RequestMapping("/")
    public String inicio(){
        return "inicio";
    }

    @RequestMapping("/InicioSesion")
    public String sesiones(){
        return "InicioSesion";
    }

    @RequestMapping("/Registrar")
    public String registro(){
        return "Registrar";
    }
    
    @RequestMapping("/RecuContra")
    public String contra(){
        return "RecuContra";
    }
}
