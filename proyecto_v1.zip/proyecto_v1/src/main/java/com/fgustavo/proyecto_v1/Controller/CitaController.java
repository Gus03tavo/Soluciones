package com.fgustavo.proyecto_v1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("Citas")
public class CitaController {
    @RequestMapping("/")
    public String cita(){
        return "citas/inicio";
    }
}
