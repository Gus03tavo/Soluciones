package com.fgustavo.proyecto_v1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Panel")
public class PanelController {
    @RequestMapping("/")
    public String panel(){
        return "panel";
    }
}
