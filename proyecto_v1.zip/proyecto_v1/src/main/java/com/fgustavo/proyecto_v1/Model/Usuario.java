package com.fgustavo.proyecto_v1.Model;

public class Usuario {
    private String id;
    private String nombre;
    private String apellido;
    private String correo;
    private int contraseña;
    private int repecontra;

    public Usuario() {
    }

    public Usuario(String id, String nombre, String apellido, String correo, int contraseña, int repecontra) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.contraseña = contraseña;
        this.repecontra = repecontra;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public int getContraseña() {
        return contraseña;
    }
    public void setContraseña(int contraseña) {
        this.contraseña = contraseña;
    }
    public int getRepecontra() {
        return repecontra;
    }
    public void setRepecontra(int repecontra) {
        this.repecontra = repecontra;
    }

    
}
