package com.fgustavo.proyecto_v1.Model;

import java.sql.Date;

public class Cita {
    private String nombre;
    private String correo;
    private Date fechaCita;
    private String especialidad;
    private String numeroTelefonico;
    private String comentario;
    
    public Cita() {
    }

    public Cita(String nombre, String correo, Date fechaCita, String especialidad, String numeroTelefonico,
            String comentario) {
        this.nombre = nombre;
        this.correo = correo;
        this.fechaCita = fechaCita;
        this.especialidad = especialidad;
        this.numeroTelefonico = numeroTelefonico;
        this.comentario = comentario;
    }
    
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public Date getFechaCita() {
        return fechaCita;
    }
    public void setFechaCita(Date fechaCita) {
        this.fechaCita = fechaCita;
    }
    public String getEspecialidad() {
        return especialidad;
    }
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    public String getNumeroTelefonico() {
        return numeroTelefonico;
    }
    public void setNumeroTelefonico(String numeroTelefonico) {
        this.numeroTelefonico = numeroTelefonico;
    }
    public String getComentario() {
        return comentario;
    }
    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    
}
