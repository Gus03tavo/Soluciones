package com.fgustavo.proyecto_v1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoV1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoV1Application.class, args);
	}

}
