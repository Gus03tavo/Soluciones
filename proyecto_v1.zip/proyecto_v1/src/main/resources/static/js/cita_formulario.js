/*
document.getElementById("cita_form").addEventListener("submit", function (e) {
    e.preventDefault(); // Evitar el envío predeterminado del formulario

    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var fecha = document.querySelector('input[type="date"]').value;
    var especialidad = document.querySelector('select').value;
    var telefono = document.getElementById("phone").value;

    var comentario = document.getElementById("message").value;

    if (!name || !email || !fecha || especialidad === "Seleccione una opción" || !telefono) {
        alert("Por favor, complete todos los campos obligatorios.");
    } else {
        if (comentario === "") {
            alert("Cita reservada");
        } else {
            alert("Cita reservada");
        }
    }
});
*/

    document.getElementById("cita_form").addEventListener("submit", function (e) {
        e.preventDefault(); // Evitar el envío predeterminado del formulario

        var name = document.getElementById("name").value;
        var email = document.getElementById("email").value;
        var fechaSeleccionada = new Date(document.querySelector('input[type="date"]').value);
        var especialidad = document.querySelector('select').value;
        var telefono = document.getElementById("phone").value;
        var comentario = document.getElementById("message").value;

        var fechaActual = new Date();

        if (!name || !email || !fechaSeleccionada || especialidad === "Seleccione una opción" || !telefono) {
            alert("Por favor, complete todos los campos obligatorios.");
        } else if (fechaSeleccionada <= fechaActual) {
            alert("La fecha seleccionada debe ser dos días posteriores a la fecha actual.");
        } else {
            if (comentario === "") {
                alert("Cita reservada!");
                // Borrar los campos después del envío exitoso
                document.getElementById("name").value = "";
                document.getElementById("email").value = "";
                document.querySelector('input[type="date"]').value = "";
                document.querySelector('select').value = "Seleccione una opción";
                document.getElementById("phone").value = "";
            } else {
                alert("Cita reservada!");
                // Borrar los campos después del envío exitoso
                document.getElementById("name").value = "";
                document.getElementById("email").value = "";
                document.querySelector('input[type="date"]').value = "";
                document.querySelector('select').value = "Seleccione una opción";
                document.getElementById("phone").value = "";
                document.getElementById("message").value = "";
            }
        }

        
    });
