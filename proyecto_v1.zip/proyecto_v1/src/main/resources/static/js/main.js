/*
function login(){
    // Obtener los valores ingresados en los campos de correo y contraseña
    var correo = document.getElementById("correo").value;
    var contrasena = document.getElementById("contraseña").value;

    // Validar el correo y la contraseña (puedes agregar tus propias reglas de validación)
    if (correo === "usuario@example.com" && contrasena === "contrasena123") {
        // Redirigir a otra página
        window.location.href = "panel.html";
    } else {
        alert("Correo o contraseña incorrectos. Por favor, inténtalo de nuevo.");
    }
}
*/

document.getElementById("formulario").addEventListener("submit", function (e) {
    e.preventDefault(); // Evitar el envío del formulario

    // Obtener el valor del campo de correo y contraseña
    var correo = document.getElementById("correo").value;
    var contraseña = document.getElementById("contraseña").value;

    // Realizar la validación de correo y contraseña aquí
    if (correo === "usuario@gmail.com" && contraseña === "usu123") {
        // Redirigir al usuario a otra página en caso de éxito
        window.location.href = "/Panel/";
    } else {
        alert("Correo o contraseña incorrectos. Por favor, inténtalo de nuevo.");
    }
});








