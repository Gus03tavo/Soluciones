document.getElementById("registro_formulario").addEventListener("submit", function (e){
    e.preventDefault();

    var nombre=document.getElementById("nombres").value;
    var apellido=document.getElementById("apellidos").value;
    var correo=document.getElementById("correo").value;
    var contrasena=document.getElementById("contrasena").value;
    var aceptoTerminos = document.getElementById("aceptoTerminos").checked;

    if (nombre && apellido && correo && contrasena && aceptoTerminos) {
        // Todos los campos están completos, redirigir al usuario a otra página
        alert("Usuario registrado");
        window.location.href = "/InicioSesion";
    }else {
        alert("Por favor, complete todos los campos y acepte los términos y condiciones.");
    }
});

/*else if(!nombre || !apellido || !correo || !contraseña || !aceptoTerminos){
    alert("Por favor, complete todos los campos y acepte los términos y condiciones.");
} */