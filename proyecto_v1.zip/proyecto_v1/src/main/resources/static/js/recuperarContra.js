document.getElementById("recovery-form").addEventListener("submit", function (e) {
    e.preventDefault();

    var email = document.getElementById("email").value;

    // Validar el correo electrónico (simplificado)
    if (email === "usuario@gmail.com") {
        alert("Mensaje de recuperación enviado al correo que ingresó.");
        document.getElementById("email").value = "";

    } else {
        alert("Por favor, ingrese un correo electrónico válido.");
    }
});
